import time


class utilities():

    def slowPrint(self):
        while True:
            for char in (self):
                print(char, end='', flush=True)
                time.sleep(0.05)
            break            
            
