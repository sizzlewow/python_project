from world import *


class Player:
    def __init__(self):
        self.x = startlocation[0]
        self.y = startlocation[0]
        self.name = None

        pass
    