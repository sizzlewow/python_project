from game import *
from world import OpeningTile

print("\n"*300)
OpeningTile.start_text()
BuildCharacter.playername()
Movement.where_to()