Internship Python project\
\
Create a Python script with at least 4 functions.\
Must contain:\
  input menu\
  output\
  logging\
  error handling\
  exit and return codes\
Must use 2 of the following:\
  Functions\
  if/else statements\
  case statements